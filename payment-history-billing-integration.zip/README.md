# Payment History + Billing Integration

## Files

- `Table.tsx`: reusable React Native + NativeWind table
- `table.types.ts`: reusable table types
- `PaymentHistory.tsx`: payment history modal and table
- `BillingPaymentHistory.tsx`: Billing button integration
- `index.ts`: exports

## Installation

Copy the files into your shared `components` folder.

## Billing usage

```tsx
<BillingPaymentHistory
  api={api}
  policyNumber={policyNumber}
/>
```

## API contract

The component expects:

```ts
api.withAuth().getPayments(policyNumber)
```

The response can be either:

```ts
{ data: { payments: Payment[] } }
```

or:

```ts
{ data: Payment[] }
```

If your existing API method is named `getPolicyPayments`, rename the call inside
`PaymentHistory.tsx` accordingly.
